
import logo from './logo.svg';
import Componente from './componentes/Componente';
import Propiedades from './componentes/Propiedades';
import Estado from './componentes/Estado';
import RenderizadoCondicional from './componentes/RenderizadoCondicional';
import RenderizadoElementos from './componentes/RenderizadoElementos';
import { EventosES6, EventosES7, MasSobreEventos } from './componentes/Eventos';
import ComunicacionComponentes from './componentes/ComunicacionComponentes';
import Suppliers from './componentes/Suppliers';
import Region from './componentes/Region';
import Categories from './componentes/Categories';
import Products from './componentes/Products';
import Employees from './componentes/Employees';
import AjaxApis from './componentes/AjaxApis';
import CicloVida from './componentes/CicloVida';
import ContadorHooks from './componentes/ContadorHooks';
import ScrollHooks from './componentes/ScrollHooks';
import RelojHooks from './componentes/RelojHooks';
import AjaxHooks from './componentes/AjaxHooks';
import Territories from './componentes/Territories';
import Orders from './componentes/Orders';
import Customers from './componentes/Customers';
import HooksPersonalizados from './componentes/HooksPersonalizados';
import 'bootstrap/dist/css/bootstrap.min.css';
import Formularios from './componentes/Formularios';
import Navbar from './componentes/Navbar';
import Shippers from './componentes/Shippers';
import CustomerDemographics from './componentes/CustomerDemographics';
import { Table, Button, Container, Modal, ModalBody, ModalHeader, FormGroup, ModalFooter } from 'reactstrap';
import { BrowserRouter as Router, Switch, Routes, Route } from 'react-router-dom';
import './App.css';
import { element } from 'prop-types';
import Referencias from './componentes/Referencias';
import ComponentesEtilizados from './componentes/ComponentesEstilizados';




function App() {

  return (

   
    <>
    
      <div>
        <Router>
          <Navbar />
          <Routes>
            <Route path="/Suppliers" element={<Suppliers />} />
            <Route path="/Region" element={<Region/>} />
            <Route path="/Products" element={<Products />} />
            <Route path="/Categories" element={<Categories/>} />
            <Route path="/Employees" element={<Employees/>} />
            <Route path="/Territories" element={<Territories/>} />
            <Route path="/Orders" element={<Orders/>} />
            <Route path="/Customers" element={<Customers/>} />
            <Route path="/CustomerDemographics" element={<CustomerDemographics/>} />
            <Route path="/Shippers" element={<Shippers/>} />
            

          </Routes>
        </Router>
      </div>


    </>
    /*
    <div>
      <HooksPersonalizados/>
    </div>
    
    <div>
      <ComponentesEtilizados/>
    </div>
    */
    
  );
}

export default App;


