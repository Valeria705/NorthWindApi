import React, { Component } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import {Table, Button, Container, Modal, ModalBody, ModalHeader, FormGroup, ModalFooter} from 'reactstrap';


 export default class App extends React.Component{
    state={
      data: []
    }
    componentDidMount() {
  
      console.log("Ejecutando Funcion componentDidMount()!!!!!!!!!!!!!!!! ");
  
      //let url = "https://localhost:44375/api/Suppliers";
      
      fetch('https://localhost:44375/api/Suppliers')
          .then(res => res.json())
          .then(json => {
        
              console.log(json);
  
              this.setState({data:json});
          });
    }
    render(){
      return(
        <>
        <Container key="44">
        <br/>
        <Button  key="545" color='primary'>Insertar nuevo</Button>
        <br/>
        <Table  key="555">
  
          <thead>
          <tr>
          <th>SupplierID</th>
          <th>CompanyName</th>
          <th>ContactName</th>
          <th>Address</th>
          <th>City</th>
          <th>Region</th>
          <th>PostalCode</th>
          <th>Country</th>
          <th>Phone</th>
          <th>Fax</th>
          <th>HomePage</th>
          <th>Opciones</th>
          </tr>
          </thead>
          <tbody>
            {this.state.data.map((elemento)=>(
              <tr key={elemento.SupplierID}>
                <td>{elemento.SupplierID}</td>
                <td>{elemento.CompanyName}</td>
                <td>{elemento.ContactName}</td>
                <td>{elemento.ContactTitle}</td>
                <td>{elemento.Address}</td>
                <td>{elemento.City}</td>
                <td>{elemento.Region}</td>
                <td>{elemento.PostalCode}</td>
                <td>{elemento.Country}</td>
                <td>{elemento.Phone}</td>
                <td>{elemento.Fax}</td>
                <td>{elemento.HomePage}</td>
                <td><Button color='primary'>Editar</Button></td>
                <td><Button color='danger'>Eliminar</Button></td>
              </tr>
  
  
            ))}
          </tbody>
        </Table>
  
  
        </Container>
        </>
      )
    }
  }