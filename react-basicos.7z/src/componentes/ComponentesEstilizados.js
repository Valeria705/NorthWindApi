import React from "react";
import styled from "styled-components";

export default function ComponentesEtilizados(){
    const MyH3= styled.h3`
        padding: 2rem;
        text-align:center;
    
    `;
    return(
        <>
        <h2>styled Components</h2>
        <h3>Hola soy un h3 stilizado con styled-componentes</h3>
        </>
    )

}
