import React, {Component} from "react";  

/* componente funcional expresado
*/
const Componente= (props)=> <h2>{props.msg}</h2>;


/* Componente funcional
function Componente(props){
    return <h2>{props.msg}</h2>;
}*/



/* Con clase
class Componente extends Component{
    render(){
        return <h2>{this.props.msg}</h2>;
    }

}*/

export default Componente;