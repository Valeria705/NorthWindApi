import React, { Component } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import {Table, Button, Container, Modal, ModalBody, ModalHeader, FormGroup, ModalFooter} from 'reactstrap';


 export default class App extends React.Component{
    state={
      data: []
    }
    componentDidMount() {
  
      console.log("Ejecutando Funcion componentDidMount()!!!!!!!!!!!!!!!! ");
  
      let url = "https://localhost:44375/api/Products";
      
      fetch(url)
          .then(res => res.json())
          .then(json => {
        
              console.log(json);
  
              this.setState({data:json});
          });
    }
    render(){
      return(
        <>
        <Container>
        <br/>
        <Button color='primary'>Insertar nuevo</Button>
        <br/>
        <Table>
  
          <thead>
          <tr>
          <th>ProductID</th>
          <th>ProductName</th>
          <th>SupplierID</th>
          <th>CategoryID</th>
          <th>QuantityPerUnit</th>
          <th>UnitPrice</th>
          <th>UnitsInStock</th>
          <th>UnitsOnOrder</th>
          <th>ReorderLevel</th>
          <th>Discontinued</th>
          <th>Opciones</th>
          </tr>
          </thead>
          <tbody>
            {this.state.data.map((elemento)=>(
              <tr key={elemento.ProductID}>
                <td>{elemento.ProductID}</td>
                <td>{elemento.ProductName}</td>
                <td>{elemento.SupplierID}</td>
                <td>{elemento.CategoryID}</td>
                <td>{elemento.QuantityPerUnit}</td>
                <td>{elemento.UnitPrice}</td>
                <td>{elemento.UnitsInStock}</td>
                <td>{elemento.UnitsOnOrder}</td>
                <td>{elemento.ReorderLevel}</td>
                <td>{elemento.Discontinued}</td>
                <td><Button color='primary'>Editar</Button></td>
                <td><Button color='danger'>Eliminar</Button></td>
              </tr>
  
  
            ))}
          </tbody>
        </Table>
  
  
        </Container>
        </>
      )
    }
  }