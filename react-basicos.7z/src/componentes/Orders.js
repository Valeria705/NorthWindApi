import React, { Component } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import {Table, Button, Container, Modal, ModalBody, ModalHeader, FormGroup, ModalFooter} from 'reactstrap';


 export default class App extends React.Component{
    state={
      data: []
    }
    componentDidMount() {
  
      console.log("Ejecutando Funcion componentDidMount()!!!!!!!!!!!!!!!! ");
  
      //let url = "https://localhost:44375/api/Suppliers";
      
      fetch('https://localhost:44375/api/orders')
          .then(res => res.json())
          .then(json => {
        
              console.log(json);
  
              this.setState({data:json});
          });
    }
    render(){
      return(
        <>
        <Container key="44">
        <br/>
        <Button  key="545" color='primary'>Insertar nuevo</Button>
        <br/>
        <Table  key="555">
  
          <thead>
          <tr>
          <th>OrderID</th>
          <th>CustomerID</th>
          <th>EmployeeID</th>
          <th>OrderDate</th>
          <th>RequiredDate</th>
          <th>ShippedDate</th>
          <th>ShipVia</th>
          <th>Freight</th>
          <th>ShipName</th>
          <th>ShipAddress</th>
          <th>ShipCity</th>
          <th>ShipRegion</th>
          <th>ShipPostalCode</th>
          <th>ShipCountry</th>
          <th>Opciones</th>
          </tr>
          </thead>
          <tbody>
            {this.state.data.map((elemento)=>(
              <tr key={elemento.OrderID}>
                <td>{elemento.OrderID}</td>
                <td>{elemento.CustomerID}</td>
                <td>{elemento.EmployeeID}</td>
                <td>{elemento.OrderDate}</td>
                <td>{elemento.RequiredDate}</td>
                <td>{elemento.ShippedDate}</td>
                <td>{elemento.ShipVia}</td>
                <td>{elemento.Freight}</td>
                <td>{elemento.ShipName}</td>
                <td>{elemento.ShipAddress}</td>
                <td>{elemento.ShipCity}</td>
                <td>{elemento.ShipRegion}</td>
                <td>{elemento.ShipPostalCode}</td>
                <td>{elemento.ShipCity}</td>
                <td>{elemento.ShipCountry}</td>
                <td><Button color='primary'>Editar</Button></td>
                <td><Button color='danger'>Eliminar</Button></td>
              </tr>
  
  
            ))}
          </tbody>
        </Table>
  
  
        </Container>
        </>
      )
    }
  }