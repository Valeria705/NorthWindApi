import React, { Component } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import {Table, Button, Container, Modal, ModalBody, ModalHeader, FormGroup, ModalFooter} from 'reactstrap';


 export default class App extends React.Component{
    state={
      data: []
    }
    componentDidMount() {
  
      console.log("Ejecutando Funcion componentDidMount()!!!!!!!!!!!!!!!! ");
  
      let url = "https://localhost:44375/api/CustomerDemographics";
      
      fetch(url)
          .then(res => res.json())
          .then(json => {
        
              console.log(json);
  
              this.setState({data:json});
          });
    }
    render(){
      return(
        <>
        <Container>
        <br/>
        <Button color='primary'>Insertar nuevo</Button>
        <br/>
        <Table>
  
          <thead>
          <tr>
          <th>CustomerTypeID</th>
          <th>CustomerDesc</th>
         
          </tr>
          </thead>
          <tbody>
            {this.state.data.map((elemento)=>(
              <tr key={elemento.CustomerTypeID}>
                <td>{elemento.CustomerTypeID}</td>
                <td>{elemento.CustomerDesc}</td>
                <td><Button color='primary'>Editar</Button></td>
                <td><Button color='danger'>Eliminar</Button></td>
              </tr>
  
  
            ))}
          </tbody>
        </Table>
  
  
        </Container>
        </>
      )
    }
  }