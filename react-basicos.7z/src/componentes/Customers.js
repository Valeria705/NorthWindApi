import React, { Component } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import {Table, Button, Container, Modal, ModalBody, ModalHeader, FormGroup, ModalFooter} from 'reactstrap';


 export default class App extends React.Component{
    state={
      data: []
    }
    componentDidMount() {
  
      console.log("Ejecutando Funcion componentDidMount()!!!!!!!!!!!!!!!! ");
  
      let url = "https://localhost:44375/api/Customers";
      
      fetch(url)
          .then(res => res.json())
          .then(json => {
        
              console.log(json);
  
              this.setState({data:json});
          });
    }
    render(){
      return(
        <>
        <Container>
        <br/>
        <Button color='primary'>Insertar nuevo</Button>
        <br/>
        <Table>
  
          <thead>
          <tr>
          <th>CustomerID</th>
          <th>CompanyName</th>
          <th>ContactName</th>
          <th>ContactTitle</th>
          <th>Address</th>
          <th>City</th>
          <th>Region</th>
          <th>PostalCode</th>
          <th>Country</th>
          <th>Phone</th>
          <th>Fax</th>
          <th>Opciones</th>
          </tr>
          </thead>
          <tbody>
            {this.state.data.map((elemento)=>(
              <tr key={elemento.CustomerID}>
                <td>{elemento.CustomerID}</td>
                <td>{elemento.CompanyName}</td>
                <td>{elemento.ContactName}</td>
                <td>{elemento.ContactTitle}</td>
                <td>{elemento.Address}</td>
                <td>{elemento.City}</td>
                <td>{elemento.Region}</td>
                <td>{elemento.PostalCode}</td>
                <td>{elemento.Country}</td>
                <td>{elemento.Phone}</td>
                <td>{elemento.Fax}</td>
                <td><Button color='primary'>Editar</Button></td>
                <td><Button color='danger'>Eliminar</Button></td>
              </tr>
  
  
            ))}
          </tbody>
        </Table>
  
  
        </Container>
        </>
      )
    }
  }