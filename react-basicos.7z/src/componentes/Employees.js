import React, { Component } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import {Table, Button, Container, Modal, ModalBody, ModalHeader, FormGroup, ModalFooter} from 'reactstrap';


 export default class App extends React.Component{
    state={
      data: []
    }
    componentDidMount() {
  
      console.log("Ejecutando Funcion componentDidMount()!!!!!!!!!!!!!!!! ");
  
      let url = "https://localhost:44375/api/Employees";
      
      fetch(url)
          .then(res => res.json())
          .then(json => {
        
              console.log(json);
  
              this.setState({data:json});
          });
    }
    render(){
      return(
        <>
        <Container key="44">
        <br/>
        <Button  key="545" color='primary'>Insertar nuevo</Button>
        <br/>
        <Table  key="555">
  
          <thead>
          <tr>
          <th>EmployeeID</th>
          <th>LastName</th>
          <th>FirstName</th>
          <th>Title</th>
          <th>TitleOfCourtesy</th>
          <th>BirthDate</th>
          <th>HireDate</th>
          <th>Address</th>
          <th>City</th>
          <th>Region</th>
          <th>PostalCode</th>
          <th>Country</th>
          <th>Extension</th>
          <th>Photo</th>
          <th>Notes</th>
          <th>ReportsTo</th>
          <th>PhotoPath</th>
          <th>Opciones</th>
          </tr>
          </thead>
          <tbody>
            {this.state.data.map((elemento)=>(
              <tr key={elemento.EmployeeID}>
                <td>{elemento.EmployeeID}</td>
                <td>{elemento.LastName}</td>
                <td>{elemento.FirstName}</td>
                <td>{elemento.Title}</td>
                <td>{elemento.TitleOfCourtesy}</td>
                <td>{elemento.BirthDate}</td>
                <td>{elemento.HireDate}</td>
                <td>{elemento.Address}</td>
                <td>{elemento.City}</td>
                <td>{elemento.Region}</td>
                <td>{elemento.PostalCode}</td>
                <td>{elemento.Country}</td>
                <td>{elemento.Extension}</td>
                <td>{elemento.Photo}</td>
                <td>{elemento.Notes}</td>
                <td>{elemento.ReportsTo}</td>
                <td>{elemento.PhotoPath}</td>
                <td><Button color='primary'>Editar</Button></td>
                <td><Button color='danger'>Eliminar</Button></td>
              </tr>
  
  
            ))}
          </tbody>
        </Table>
  
  
        </Container>
        </>
      )
    }
  }