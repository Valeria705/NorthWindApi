import React, { Component } from "react";


function Pokemon(props) {
    return (
        <figure>
            <img src={props.avatar} alt={props.name} width="50" />
            <figcaption>{props.name}</figcaption>
        </figure>

    );
}

export default class AjaxApis extends Component {
    state = {
        pokemons: []
    };



    componentDidMount() {

        //console.log("Ejecutando Funcion componentDidMount()!!!!!!!!!!!!!!!! ");

        let url = "https://pokeapi.co/api/v2/pokemon";
        fetch(url)
            .then(res => res.json())
            .then(json => {
                //console.log("Antes....");
                //console.log(json.results);
                //console.log("Despues--- TOTAL: " + json.results.length);

        

                json.results.forEach(el => {

                   // console.log("Foreach Antes: " + el.name);
                    //console.log(el);
                    //console.log("Fetching Pokemon URL: " + el.url);

                    fetch(el.url)
                        .then(res => res.json())
                        .then(json => {


                            let pokemon = {
                                id: json.id,
                                name: json.name,
                                avatar: json.sprites.front_default,
                                key: json.id
                            };

                           // console.log("Pushing Id: " + json.id);
                            //console.log("Size pokemons: " + this.state.pokemons.length);



                            //solucion 2 youtube:
                           // let pokemons=[...this.state.pokemons, pokemon];
                           // this.setState({pokemons});

                           //solucion 3
                           this.state.pokemons.push(pokemon);
                           this.setState({pokemons:this.state.pokemons});

                            //console.log("FINAL lista: " + lista.length);
                            // 
                             
                     
                           
                        });



                });

     
                
            });


    }

    render() {

        //console.log("render().................. size: " + this.state.pokemons.length)

        return (
            <>
                <h2>Peticiones Asincronas en Componentes de clase: {this.state.pokemons.length}</h2>
                {this.state.pokemons.map((el) => (
                    <Pokemon key={el.id} name={el.name} avatar={el.avatar} />
                ))}
            </>
        )


    }
}