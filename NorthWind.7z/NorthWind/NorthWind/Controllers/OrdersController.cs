﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class OrdersController : Controller
    {
        OrdersService ordersService = new OrdersService();
        CustomersService cusService = new CustomersService();
        EmployeesService employeesService = new EmployeesService();

        [HttpGet]
        public ActionResult Select()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Orders> listOrders = ordersService.GetAllOrders();
            ViewBag.listOrders = listOrders;
            return View();
        }

        [HttpGet]
        public ActionResult Update(int id)
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Customers> customers = cusService.GetAllCustomers();
            List<Employees> employees = employeesService.GetAllEmployees();

            ViewBag.customers = customers;
            ViewBag.employees = employees;
            ViewBag.Order = ordersService.GetOrderById(id);

            return View();
        }

        [HttpGet]
        public ActionResult Insert()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Customers> customers = cusService.GetAllCustomers();
            List<Employees> employees = employeesService.GetAllEmployees();

            ViewBag.customers = customers;
            ViewBag.employees = employees;

            return View();
        }

        [HttpPost]
        public ActionResult InsertAction(Orders s)
        {
            s.OrderDate = DateTime.ParseExact(Request.Params["OrderDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);
            s.RequiredDate = DateTime.ParseExact(Request.Params["RequiredDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);
            s.ShippedDate = DateTime.ParseExact(Request.Params["ShippedDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);

            ordersService.InsertOrder(s);
            return RedirectToAction("Select");
        }

        [HttpPost]
        public ActionResult UpdateAction(Orders s)
        {
            s.OrderDate = DateTime.ParseExact(Request.Params["OrderDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);
            s.RequiredDate = DateTime.ParseExact(Request.Params["RequiredDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);
            s.ShippedDate = DateTime.ParseExact(Request.Params["ShippedDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);

            ordersService.UpdateOrder(s);
            return RedirectToAction("Select");
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            ViewBag.Order = ordersService.DeleteOrderById(id);
            return RedirectToAction("Select");
        }


      

    }
}