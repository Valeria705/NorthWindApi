﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class ShippersController : Controller
    {
        ShippersService shippersService = new ShippersService();

        public ActionResult Select()
        {

            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index","Home");
            }

            List<Shippers> listShippers = shippersService.GetAllShippers();
            ViewBag.listShippers = listShippers;
            return View();
        }


        public ActionResult Update(int id)
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.shipper = shippersService.GetShipperById(id);
            return View();
        }


        public ActionResult Insert()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }


        public ActionResult InsertAction(Shippers s)
        {
            shippersService.InsertShipper(s);
            return RedirectToAction("Select");
        }


        public ActionResult UpdateAction(Shippers s)
        {
            shippersService.UpdateShipper(s);
            return RedirectToAction("Select");
        }


        
        public ActionResult Delete(int id)
        {
            ViewBag.shipper = shippersService.DeleteShipperById(id);
            return RedirectToAction("Select");
        }


    }
}