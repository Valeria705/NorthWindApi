﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class CategoriesController : Controller
    {
        CategoriesService CategoriesService = new CategoriesService();

        public ActionResult Select()

        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }

            List<Categories> listCategories = CategoriesService.GetAllCategories();
            ViewBag.listCategories = listCategories;
            return View();
        }


        public ActionResult Update(int id)
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.Categorie = CategoriesService.GetCategorieById(id);
            return View();
        }


        public ActionResult Insert()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }


        public ActionResult InsertAction(Categories s)
        {
            CategoriesService.InsertCategorie(s);
            return RedirectToAction("Select");
        }


        public ActionResult UpdateAction(Categories s)
        {
            CategoriesService.UpdateCategorie(s);
            return RedirectToAction("Select");
        }


        
        public ActionResult Delete(int id)
        {
            ViewBag.Categorie = CategoriesService.DeleteCategorieById(id);
            return RedirectToAction("Select");
        }


    }
}