﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class TerritoriesController : Controller
    {
        TerritoriesService territoriesService = new TerritoriesService();
        RegionService regionService = new RegionService();

        [HttpGet]
        public ActionResult Select()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Territories> listTerritories = territoriesService.GetAllTerritories();
            ViewBag.listTerritories = listTerritories;
            return View();
        }


        [HttpGet]
        public ActionResult Update(string id)
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            IEnumerable<Region> region = regionService.GetAllRegion();
            ViewBag.region = region;
            ViewBag.Territories = territoriesService.GetTerritorieById(id);
            return View();
        }


        [HttpGet]
        public ActionResult Insert()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            IEnumerable<Region> region = regionService.GetAllRegion();
            ViewBag.region = region;
            return View();
        }


        [HttpPost]
        public ActionResult InsertAction(Territories s)
        {
            territoriesService.InsertTerritorie(s);
            return RedirectToAction("Select");
        }


        [HttpPost]
        public ActionResult UpdateAction(Territories s)
        {
            territoriesService.UpdateTerritorie(s);
            return RedirectToAction("Select");
        }



        [HttpGet]
        public ActionResult Delete(string id)
        {
            ViewBag.Territorie = territoriesService.DeleteTerritorieById(id);
            return RedirectToAction("Select");
        }


    }
}