﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class ProductsController : Controller
    {
        ProductsService productsService = new ProductsService();
        CategoriesService categoriesService = new CategoriesService();
        SuppliersService suppliersService = new SuppliersService();

        public ActionResult Select()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Products> listProducts = productsService.GetAllProducts();
            ViewBag.listProducts = listProducts;
            return View();
        }


        public ActionResult Update(int id)
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Categories> categories = categoriesService.GetAllCategories();
            List<Suppliers> suppliers = suppliersService.GetAllSuppliers();

            ViewBag.categories = categories;
            ViewBag.suppliers = suppliers;
            ViewBag.Product = productsService.GetProductById(id);
            return View();
        }


        public ActionResult Insert()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Categories> categories = categoriesService.GetAllCategories();
            List<Suppliers> suppliers = suppliersService.GetAllSuppliers();

            ViewBag.categories = categories;
            ViewBag.suppliers = suppliers;
            return View();
        }


        public ActionResult InsertAction(Products s)
        {
            productsService.InsertProduct(s);
            return RedirectToAction("Select");
        }


        public ActionResult UpdateAction(Products s)
        {
            productsService.UpdateProduct(s);
            return RedirectToAction("Select");
        }


        
        public ActionResult Delete(int id)
        {
            ViewBag.Product = productsService.DeleteProductById(id);
            return RedirectToAction("Select");
        }


    }
}