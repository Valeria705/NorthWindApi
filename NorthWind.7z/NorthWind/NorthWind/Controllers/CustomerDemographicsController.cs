﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class CustomerDemographicsController : Controller
    {
        CustomerDemographicsService customerDemographicsService = new CustomerDemographicsService();

        public ActionResult Select()

        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }

            List<CustomerDemographics> listCustomerDemographics = customerDemographicsService.GetAllCustomerDemographics();
            ViewBag.listCustomerDemographics = listCustomerDemographics;
            return View();
        }


        public ActionResult Update(string id)
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.CustomerDemographics = customerDemographicsService.GetCustomerDemographicsById(id);
            return View();
        }


        public ActionResult Insert()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }


        public ActionResult InsertAction(CustomerDemographics s)
        {

            customerDemographicsService.InsertCustomerDemographics(s);
            return RedirectToAction("Select");
        }


        public ActionResult UpdateAction(CustomerDemographics s)
        {
            customerDemographicsService.UpdateCustomerDemographics(s);
            return RedirectToAction("Select");
        }

         
        
        public ActionResult Delete(string id)
        {
            ViewBag.CustomerDemographic = customerDemographicsService.DeleteCustomerDemographicsById(id);
            return RedirectToAction("Select");
        }


    }
}