﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class RegionController : Controller
    {
        RegionService regionService = new RegionService();

        public ActionResult Select()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            IEnumerable<Region> listRegion = regionService.GetAllRegion();
            ViewBag.listRegion = listRegion;
            return View();
        }


        public ActionResult Update(int id)
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.Region = regionService.GetRegionById(id);
            return View();
        }


        public ActionResult Insert()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }


        public ActionResult InsertAction(Region s)
        {
            regionService.InsertRegion(s);
            return RedirectToAction("Select");
        }


        public ActionResult UpdateAction(Region s)
        {
            regionService.UpdateRegion(s);
            return RedirectToAction("Select");
        }


        
        public ActionResult Delete(int id)
        {
            ViewBag.Region = regionService.DeleteRegionById(id);
            return RedirectToAction("Select");
        }


    }
}