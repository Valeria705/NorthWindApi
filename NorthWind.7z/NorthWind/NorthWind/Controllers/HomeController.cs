﻿
using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login()
        {

        
           string login = Request.Params["login"];
           string password = Request.Params["password"];

            //ir a la base de datos y preguntas si existe ese usuario y password con SQL y clave encriptada

            UsersService usersService= new UsersService();

            Users x         =         usersService.GetUserByLoginAndPassword(login, password);




           System.Web.HttpContext.Current.Session["idUser"] = x.IdUser;
           System.Web.HttpContext.Current.Session["nameUser"]= x.FirtsNameUser + x.LastsNameUser; //first + last name

            return RedirectToAction("Index");
        }


        [HttpGet]
        public ActionResult Logout()
        {
            System.Web.HttpContext.Current.Session["idUser"] = null;
            System.Web.HttpContext.Current.Session["nameUser"] = null;
            return RedirectToAction("Index");
        }



        public ActionResult MisionVision()
        {
    
            ViewBag.Title = "Mision y Vision";
            return View();
        }

    
    }
}