﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class CustomersController : Controller
    {
        CustomersService customersService = new CustomersService();
        CustomerDemographicsService customerDemographicsService = new CustomerDemographicsService();
        CustomerCustomerDemoService customerCustomerDemoService = new CustomerCustomerDemoService();
        public ActionResult Select()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Customers> listCustomers = customersService.GetAllCustomers();
            ViewBag.listCustomers = listCustomers;

            return View();
        }


        public ActionResult Update(string id)
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Customers> customers = customersService.GetAllCustomers();
            Customers customer = customersService.GetCustomerById(id);
            List<CustomerDemographics> customerDemographics = customerDemographicsService.GetAllCustomerDemographics();
            List<CustomerCustomerDemo> customerCustomerDemo = customerCustomerDemoService.GetCustomerCustomerDemoByCustomerId(id);

            ViewBag.customer = customer;
            ViewBag.customers = customers;
            ViewBag.customerDemographics = customerDemographics;
            ViewBag.customerCustomerDemo = customerCustomerDemo;


            return View();
        }


        public ActionResult Insert()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Customers> customers = customersService.GetAllCustomers();

            List<CustomerDemographics> customerDemographics = customerDemographicsService.GetAllCustomerDemographics();

            ViewBag.customers = customers;

            ViewBag.customerDemographics = customerDemographics;

            return View();
        }

        [HttpPost]
        public ActionResult InsertAction(Customers s)
        {
            
            customersService.InsertCustomer(s);

       
       
           if (s.CustomerDemographics != null)
           {
               foreach (string item in s.CustomerDemographics)
                {
                    CustomerCustomerDemo nuevo = new CustomerCustomerDemo();
                   nuevo.CustomerID = s.CustomerID;
                   nuevo.CustomerTypeID = item;

                    customerCustomerDemoService.InsertCustomerCustomer(nuevo);
                }
            }

            return RedirectToAction("Select");
        }


        public ActionResult UpdateAction(Customers s)
        {
            customersService.UpdateCustomer(s);

            customerCustomerDemoService.DeleteCustomerByCustomerID(s.CustomerID);


            if (s.CustomerDemographics != null)
            {
                foreach (string item in s.CustomerDemographics)
                {
                    CustomerCustomerDemo nuevo = new CustomerCustomerDemo();
                    nuevo.CustomerID = s.CustomerID;
                    nuevo.CustomerTypeID = item;

                    customerCustomerDemoService.InsertCustomerCustomer(nuevo);
                }
            }


            return RedirectToAction("Select");
        }



        
        public ActionResult Delete(string id)

        {
            customerCustomerDemoService.DeleteCustomerByCustomerID(id);

            ViewBag.Customer = customersService.DeleteCustomerById(id);
            return RedirectToAction("Select");
        }


    }
}