﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class UsersController : Controller
    {
        UsersService UsersService = new UsersService();
        RegionService regionService = new RegionService();

        [HttpGet]
        public ActionResult Select()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Users> listUsers = UsersService.GetAllUsers();
            ViewBag.listUsers = listUsers;
            return View();
        }


        [HttpGet]
        public ActionResult Update(string id)
        {
            
            ViewBag.User = UsersService.GetUserById(id);
            return View();
        }


        [HttpGet]
        public ActionResult Insert()
        {
            IEnumerable<Region> region = regionService.GetAllRegion();
            ViewBag.region = region;
            return View();
        }


        [HttpPost]
        public ActionResult InsertAction(Users s)
        {
            UsersService.InsertUser(s);
            return RedirectToAction("Select");
        }


        [HttpPost]
        public ActionResult UpdateAction(Users s)
        {
            UsersService.UpdateUser(s);
            return RedirectToAction("Select");
        }



        [HttpGet]
        public ActionResult Delete(string id)
        {
            ViewBag.User = UsersService.DeleteUserById(id);
            return RedirectToAction("Select");
        }


    }
}