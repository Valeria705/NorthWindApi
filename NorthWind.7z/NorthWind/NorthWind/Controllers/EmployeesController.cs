﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class EmployeesController : Controller
    {
        EmployeesService employeesService = new EmployeesService();
        TerritoriesService territoriesService = new TerritoriesService();
        EmployeeTerritoriesService employeeTerritoriesService = new EmployeeTerritoriesService();

        [HttpGet]
        public ActionResult Select()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Employees> listEmployees = employeesService.GetAllEmployees();
            ViewBag.listEmployees = listEmployees;
            return View();
        }

        [HttpGet]
        public ActionResult Update(int id)
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Employees> employees = employeesService.GetAllEmployees();
            Employees employee = employeesService.GetEmployeeById(id);
            List<Territories> territories = territoriesService.GetAllTerritories();
            List<EmployeeTerritories> eployeeTerritories = employeeTerritoriesService.GetEmployeeTerritoriesByEmployeeId(id);

            ViewBag.employee = employee;
            ViewBag.employees= employees;
            ViewBag.territories = territories;
            ViewBag.eployeeTerritories = eployeeTerritories;


            return View();
        }

        [HttpGet]
        public ActionResult Insert()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }

            List<Employees> employees = employeesService.GetAllEmployees();

            List<Territories> territories = territoriesService.GetAllTerritories();

            ViewBag.employees = employees;

            ViewBag.territories = territories;
    
            return View();
        }

        [HttpPost]
        public ActionResult InsertAction(Employees s)
        {

            s.BirthDate = DateTime.ParseExact(Request.Params["BirthDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);
            s.HireDate = DateTime.ParseExact(Request.Params["HireDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);

            s.EmployeeID = employeesService.InsertEmployee(s);



            if (s.Territories!=null)
            {
                foreach (string item in s.Territories)
                {
                    EmployeeTerritories nuevo = new EmployeeTerritories();
                    nuevo.EmployeeID = s.EmployeeID;
                    nuevo.TerritoryID = item;

                    employeeTerritoriesService.InsertEmployeeTerritorie(nuevo);
                }
            }



            return RedirectToAction("Select");
        }

        [HttpPost]
        public ActionResult UpdateAction(Employees s)
        {
            s.BirthDate = DateTime.ParseExact(Request.Params["BirthDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);
            s.HireDate = DateTime.ParseExact(Request.Params["HireDate"], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);

            employeesService.UpdateEmployee(s);


            employeeTerritoriesService.DeleteEmployeeTerritorieByEmployeeID(s.EmployeeID);


            if (s.Territories != null)
            {
                foreach (string item in s.Territories)
                {
                    EmployeeTerritories nuevo = new EmployeeTerritories();
                    nuevo.EmployeeID = s.EmployeeID;
                    nuevo.TerritoryID = item;

                    employeeTerritoriesService.InsertEmployeeTerritorie(nuevo);
                }
            }

            return RedirectToAction("Select");
        }


        [HttpGet]
        public ActionResult Delete(int id)
        {

            employeeTerritoriesService.DeleteEmployeeTerritorieByEmployeeID(id);

            employeesService.DeleteEmployeeById(id);
            return RedirectToAction("Select");
        }


      

    }
}