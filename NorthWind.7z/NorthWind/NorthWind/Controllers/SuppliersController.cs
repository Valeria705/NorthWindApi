﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace NorthWind.Controllers
{
    public class SuppliersController : Controller
    {
        SuppliersService suppliersService = new SuppliersService();



        public string Json()
        {
            Response.ContentType = "application/json";

            List<Suppliers> listSuppliers = suppliersService.GetAllSuppliers();

            string x = "[";

            for (int i = 0; i < listSuppliers.Count; i++)
            {
                Suppliers supplier = listSuppliers.ElementAt(i);

                x += "{\"supplierID\":\""+ supplier.SupplierID + "\",  \"companyName\":\""+ supplier.CompanyName +"\", \"address\":\""+ supplier.Address +"\" }";

                if (i+1 < listSuppliers.Count)
                {
                    x += ",";
                }
            
            }

            x += "]";

            return x;
        }



        public ActionResult Select()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<Suppliers> listSuppliers = suppliersService.GetAllSuppliers();
            ViewBag.listSuppliers = listSuppliers;
            return View();
        }


        public ActionResult Update(int id)
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.Supplier = suppliersService.GetSupplierById(id);
            return View();
        }


        public ActionResult Insert()
        {
            if (System.Web.HttpContext.Current.Session["idUser"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }


        public ActionResult InsertAction(Suppliers s)
        {
            suppliersService.InsertSupplier(s);
            return RedirectToAction("Select");
        }


        public ActionResult UpdateAction(Suppliers s)
        {
            suppliersService.UpdateSupplier(s);
            return RedirectToAction("Select");
        }


        
        public ActionResult Delete(int id)
        {
            ViewBag.Supplier = suppliersService.DeleteSupplierById(id);
            return RedirectToAction("Select");
        }


    }
}