﻿using NorthWind.Models;
using NorthWind.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWind.Controllers
{
    public class OrderDetailsController : Controller
    {
        OrderDetailsService OrderDetailsService = new OrderDetailsService();
        OrdersService ordersService= new OrdersService();
        ProductsService productsService= new ProductsService();

        [HttpGet]
        public ActionResult Select(int id)
        {
            List<OrderDetails> listOrderDetails = OrderDetailsService.GetOrderDetailsByOrderId(id);
            ViewBag.listOrderDetails = listOrderDetails;


            Orders order =  ordersService.GetOrderById(id);
            ViewBag.order = order;

            return View();
        }

        [HttpGet]
        public ActionResult Update(int id)
        {
           
            Orders order = ordersService.GetOrderById(id);
            List<Products> products = productsService.GetAllProducts();
            ViewBag.products = products;
            ViewBag.order = order;
            ViewBag.OrderDetail = OrderDetailsService.GetOrderDetailById(id);
            return View();
        }

        [HttpGet]
        public ActionResult Insert(int id)
        {
            
            Orders order = ordersService.GetOrderById(id);
            List<Products> products = productsService.GetAllProducts();
            ViewBag.products = products;
            ViewBag.order= order;
            return View();
        }

        [HttpPost]
        public ActionResult InsertAction(OrderDetails s)
        {
            OrderDetailsService.InsertOrderDetail(s);
            return RedirectToAction("Select/"+s.OrderID);
        }

        [HttpPost]
        public ActionResult UpdateAction(OrderDetails s)
        {
            OrderDetailsService.UpdateOrderDetail(s);
            return RedirectToAction("Select/" + s.OrderID);
        }


        [HttpGet]
        public ActionResult Delete(int id, int ProductID)
        {
            ViewBag.OrderDetail = OrderDetailsService.DeleteOrderDetailById(id, ProductID);
            return RedirectToAction("Select/" + id);
        }


    }
}