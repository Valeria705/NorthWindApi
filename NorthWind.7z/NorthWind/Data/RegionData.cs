﻿
using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class RegionData
    {
        public List<Region> GetAllRegion()
        {
            List<Region> list = new List<Region>();
            string queryString = "SELECT * FROM Region";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Region x = new Region();
                    x.RegionID = Convert.ToInt32( reader["RegionID"]);
                    x.RegionDescription = Convert.ToString( reader["RegionDescription"]);
                  
                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteRegionById(int id)
        {
            int result = 0;
            string queryString = "DELETE FROM Region WHERE RegionID='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int UpdateRegion(Region a)
        {
            int result = 0;
            string queryString = "UPDATE Region SET RegionDescription='" + a.RegionDescription + "' WHERE RegionID='"+a.RegionID+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public Region GetRegionById(int id)
        {
            Region item = null;
            string queryString = "SELECT * FROM Region WHERE RegionID='"+id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new Region();
                    item.RegionID = Convert.ToInt32(reader["RegionID"]);
                    item.RegionDescription = Convert.ToString(reader["RegionDescription"]);
       
                }
                reader.Close();
            }
            return item;
        }

        public int InsertRegion(Region a)
        {
            int result = 0;
            string queryString = "INSERT INTO Region(RegionID, RegionDescription) VALUES('" + a.RegionID + "','" + a.RegionDescription+"')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
    }
}