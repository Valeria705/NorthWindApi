﻿
using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class SuppliersData
    {
        public List<Suppliers> GetAllSuppliers()
        {
            List<Suppliers> list = new List<Suppliers>();
            string queryString = "SELECT * FROM Suppliers";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Suppliers x = new Suppliers();
                    x.SupplierID = Convert.ToInt32( reader["SupplierID"]);
                    x.CompanyName = Convert.ToString( reader["CompanyName"]);
                    x.ContactName = Convert.ToString( reader["ContactName"]);
                    x.ContactTitle = Convert.ToString(reader["ContactTitle"]);
                    x.Address = Convert.ToString(reader["Address"]);
                    x.City = Convert.ToString(reader["City"]);
                    x.Region = Convert.ToString(reader["Region"]);
                    x.PostalCode = Convert.ToString(reader["PostalCode"]);
                    x.Country = Convert.ToString(reader["Country"]);
                    x.Phone = Convert.ToString(reader["Phone"]);
                    x.Fax = Convert.ToString(reader["Fax"]);
                    x.HomePage = Convert.ToString(reader["HomePage"]);
                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteSupplierById(int id)
        {
            int result = 0;
            string queryString = "DELETE FROM Suppliers WHERE SupplierID='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int UpdateSupplier(Suppliers a)
        {
            int result = 0;
            string queryString = "UPDATE Suppliers SET CompanyName='" + a.CompanyName + "', ContactName='" + a.ContactName + "', ContactTitle='" + a.ContactTitle + "', Address='" + a.Address + "', City='" + a.City + "', Region='" + a.Region + "', PostalCode='" + a.PostalCode + "', Country='" + a.Country + "' , Phone='" + a.Phone + "', Fax='" + a.Fax + "', HomePage='" + a.HomePage + "' WHERE SupplierID='" + a.SupplierID + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public Suppliers GetSupplierById(int id)
        {
            Suppliers item = null;
            string queryString = "SELECT * FROM Suppliers WHERE SupplierID='" + id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new Suppliers();
                    item.SupplierID = Convert.ToInt32(reader["SupplierID"]);
                    item.CompanyName = Convert.ToString(reader["CompanyName"]);
                    item.ContactName = Convert.ToString(reader["ContactName"]);
                    item.ContactTitle = Convert.ToString(reader["ContactTitle"]);
                    item.Address = Convert.ToString(reader["Address"]);
                    item.City = Convert.ToString(reader["City"]);
                    item.Region = Convert.ToString(reader["Region"]);
                    item.PostalCode = Convert.ToString(reader["PostalCode"]);
                    item.Country = Convert.ToString(reader["Country"]);
                    item.Phone = Convert.ToString(reader["Phone"]);
                    item.Fax = Convert.ToString(reader["Fax"]);
                    item.HomePage = Convert.ToString(reader["HomePage"]);
                }
                reader.Close();
            }
            return item;
        }

        public int InsertSupplier(Suppliers a)
        {
            int result = 0;
            string queryString = "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('" + a.CompanyName + "','"+a.ContactName + "','" + a.ContactTitle + "','" + a.Address + "','" + a.City + "','" + a.Region + "','" + a.PostalCode + "','" + a.Country + "','" + a.Phone + "','" + a.Fax + "','" + a.HomePage + "')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
    }
}