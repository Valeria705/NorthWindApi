﻿using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class CustomersData
    {
        public List<Customers> GetAllCustomers()
        {
            List<Customers> list = new List<Customers>();
            string queryString = "SELECT * FROM Customers ORDER BY CompanyName";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Customers x = new Customers();
                    x.CustomerID = Convert.ToString( reader["CustomerID"]);
                    x.CompanyName = Convert.ToString( reader["CompanyName"]);
                    x.ContactName = Convert.ToString( reader["ContactName"]);
                    x.ContactTitle = Convert.ToString(reader["ContactTitle"]);
                    x.Address = Convert.ToString(reader["Address"]);
                    x.City = Convert.ToString(reader["City"]);
                    x.Region = Convert.ToString(reader["Region"]);
                    x.PostalCode = Convert.ToString(reader["PostalCode"]);
                    x.Country = Convert.ToString(reader["Country"]);
                    x.Phone = Convert.ToString(reader["Phone"]);
                    x.Fax = Convert.ToString(reader["Fax"]);

                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteCustomerById(string id)
        {
            int result = 0;
            string queryString = "DELETE FROM Customers WHERE CustomerID='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int UpdateCustomer(Customers a)
        {
            int result = 0;
            string queryString = "UPDATE Customers SET CompanyName='" + a.CompanyName + "', ContactName='" + a.ContactName + "', ContactTitle='" + a.ContactTitle + "', Address='" + a.Address + "', City='" + a.City + "', Region='" + a.Region + "', PostalCode='" + a.PostalCode + "', Country='" + a.Country + "', Phone='" + a.Phone + "', Fax='" + a.Fax + "' WHERE CustomerID='" + a.CustomerID+"';" +
                " SELECT SCOPE_IDENTITY();";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public Customers GetCustomerById(string id)
        {
            Customers x = null;
            string queryString = "SELECT * FROM Customers WHERE CustomerID='"+id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    x = new Customers();
                    x.CustomerID = Convert.ToString(reader["CustomerID"]);
                    x.CompanyName = Convert.ToString(reader["CompanyName"]);
                    x.ContactName = Convert.ToString(reader["ContactName"]);
                    x.ContactTitle = Convert.ToString(reader["ContactTitle"]);
                    x.Address = Convert.ToString(reader["Address"]);
                    x.City = Convert.ToString(reader["City"]);
                    x.Region = Convert.ToString(reader["Region"]);
                    x.PostalCode = Convert.ToString(reader["PostalCode"]);
                    x.Country = Convert.ToString(reader["Country"]);
                    x.Phone = Convert.ToString(reader["Phone"]);
                    x.Fax = Convert.ToString(reader["Fax"]);
                }
                reader.Close();
            }
            return x;
        }

        public int InsertCustomer(Customers a)
        {
            int result = 0;
            string queryString = "INSERT INTO Customers(CustomerID,CompanyName,ContactName,ContactTitle, Address,City,Region,PostalCode,Country,Phone,Fax) " +
                "VALUES('" + a.CustomerID + "','" + a.CompanyName+"','"+a.ContactName + "','" + a.ContactTitle + "','" + a.Address + "','" + a.City + "','" + a.Region + "','" + a.PostalCode + "','" + a.Country + "','" + a.Phone + "','" + a.Fax + "')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
    }
}