﻿using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class ProductsData
    {
        public List<Products> GetAllProducts()
        {
            List<Products> list = new List<Products>();
                                                                    
            string queryString = "SELECT"+
                                    " Products.CategoryID, "+
                                    "Products.Discontinued, "+
                                    "Products.ProductID, "+
                                    "Products.ProductName, "+
                                    "Products.QuantityPerUnit, "+
                                    "Products.ReorderLevel, "+
                                    "Products.SupplierID, "+
                                    "Products.UnitPrice, "+
                                    "Products.UnitsInStock, "+
                                    "Products.UnitsOnOrder, "+
                                    "Suppliers.CompanyName, "+
                                    "Categories.CategoryName "+
                                    "FROM Products "+
                                    "INNER JOIN Suppliers ON Products.SupplierID= Suppliers.SupplierID "+
                                    "INNER JOIN Categories ON Products.CategoryID= Categories.CategoryID ";


            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Products x = new Products();
                    x.ProductID = Convert.ToInt32( reader["ProductID"]);
                    x.ProductName = Convert.ToString( reader["ProductName"]);
                    x.SupplierID = Convert.ToInt32( reader["SupplierID"]);
                    x.CategoryID = Convert.ToInt32(reader["CategoryID"]);
                    x.QuantityPerUnit = Convert.ToString(reader["QuantityPerUnit"]);
                    x.UnitPrice = Convert.ToDecimal(reader["UnitPrice"]);
                    x.UnitsInStock = Convert.ToInt32(reader["UnitsInStock"]);
                    x.UnitsOnOrder = Convert.ToInt32(reader["UnitsOnOrder"]);
                    x.ReorderLevel = Convert.ToInt32(reader["ReorderLevel"]);
                    x.Discontinued = Convert.ToBoolean(reader["Discontinued"]);

                    x.Suppliers = new Suppliers();
                    x.Suppliers.SupplierID = x.SupplierID;
                    x.Suppliers.CompanyName = Convert.ToString(reader["CompanyName"]);

                    x.Categories = new Categories();
                    x.Categories.CategoryID = x.CategoryID;
                    x.Categories.CategoryName = Convert.ToString(reader["CategoryName"]);

                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteProductById(int id)
        {
            int result = 0;
            string queryString = "DELETE FROM Products WHERE ProductID='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int UpdateProduct(Products a)
        {
            int result = 0;
            string queryString = "UPDATE Products SET ProductName='" + a.ProductName + "', SupplierID='" + a.SupplierID + "', CategoryID='" + a.CategoryID + "', QuantityPerUnit='" + a.QuantityPerUnit + "', UnitPrice='" + a.UnitPrice + "', UnitsInStock='" + a.UnitsInStock + "', UnitsOnOrder='" + a.UnitsOnOrder + "', ReorderLevel='" + a.ReorderLevel + "' , Discontinued='" + a.Discontinued + "' WHERE ProductID='" + a.ProductID + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public Products GetProductById(int id)
        {
            Products item = null;
            string queryString = "SELECT * FROM Products WHERE ProductID='" + id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new Products();
                    item.ProductID = Convert.ToInt32(reader["ProductID"]);
                    item.ProductName = Convert.ToString(reader["ProductName"]);
                    item.SupplierID = Convert.ToInt32(reader["SupplierID"]);
                    item.CategoryID = Convert.ToInt32(reader["CategoryID"]);
                    item.QuantityPerUnit = Convert.ToString(reader["QuantityPerUnit"]);
                    item.UnitPrice = Convert.ToDecimal(reader["UnitPrice"]);
                    item.UnitsInStock = Convert.ToInt32(reader["UnitsInStock"]);
                    item.UnitsOnOrder = Convert.ToInt32(reader["UnitsOnOrder"]);
                    item.ReorderLevel = Convert.ToInt32(reader["ReorderLevel"]);
                    item.Discontinued = Convert.ToBoolean(reader["Discontinued"]);
                }
                reader.Close();
            }
            return item;
        }

        public int InsertProduct(Products a)
        {
            int result = 0;
            string queryString = "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued) VALUES('" + a.ProductName + "','"+a.SupplierID + "','" + a.CategoryID + "','" + a.QuantityPerUnit + "','" + a.UnitPrice + "','" + a.UnitsInStock + "','" + a.UnitsOnOrder + "','" + a.ReorderLevel + "','" + a.Discontinued + "')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
    }
}