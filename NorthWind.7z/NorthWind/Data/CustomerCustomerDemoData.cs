﻿
using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class CustomerCustomerDemoData
    {

        public List<CustomerCustomerDemo> GetCustomerCustomerDemoByCustomerId(string customerID)
        {
            List<CustomerCustomerDemo> list = new List<CustomerCustomerDemo>();
            string queryString = "SELECT * FROM CustomerCustomerDemo WHERE CustomerID='" + customerID + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    CustomerCustomerDemo x = new CustomerCustomerDemo();
                    x.CustomerID = Convert.ToString( reader["CustomerID"]);
                    x.CustomerTypeID = Convert.ToString( reader["CustomerTypeID"]);
                 
                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteCustomerByCustomerID(string CustomerID)
        {

            int result = 0;
            string queryString = "DELETE FROM CustomerCustomerDemo WHERE CustomerID='" + CustomerID + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int InsertCustomer(CustomerCustomerDemo a)
        {
            int result = 0;
          string queryString = "INSERT INTO CustomerCustomerDemo(CustomerID,CustomerTypeID) VALUES('" + a.CustomerID + "','" + a.CustomerTypeID + "')";
          using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
          {
              SqlCommand command = new SqlCommand(queryString, connection);
              connection.Open();
              result = command.ExecuteNonQuery();
          }
            return result;
        }
    }
}