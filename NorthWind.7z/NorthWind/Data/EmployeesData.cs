﻿
using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class EmployeesData
    {
        public List<Employees> GetAllEmployees()
        {
            List<Employees> list = new List<Employees>();
            string queryString = "SELECT E.*,W.FirstName  as 'ReportsToFirstName',W.LastName  as 'ReportsToLastName' FROM Employees as E LEFT JOIN Employees as W ON E.ReportsTo = W.EmployeeID";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Employees item = new Employees();
                    item.EmployeeID = Convert.ToInt32( reader["EmployeeID"]);
                    item.LastName = Convert.ToString( reader["LastName"]);
                    item.FirstName = Convert.ToString( reader["FirstName"]);
                    item.Title = Convert.ToString(reader["Title"] is DBNull ? null : reader["Title"]);
                    item.TitleOfCourtesy = Convert.ToString(reader["TitleOfCourtesy"] is DBNull ? null : reader["TitleOfCourtesy"]);
                    item.BirthDate = Convert.ToDateTime(reader["BirthDate"] is DBNull ? null : reader["BirthDate"]);
                    item.HireDate = Convert.ToDateTime(reader["HireDate"] is DBNull ? null : reader["HireDate"]);
                    item.Address = Convert.ToString(reader["Address"] is DBNull ? null : reader["Address"]);
                    item.City = Convert.ToString(reader["City"] is DBNull ? null : reader["City"]);
                    item.Region = Convert.ToString(reader["Region"] is DBNull ? null : reader["Region"]);
                    item.PostalCode = Convert.ToString(reader["PostalCode"] is DBNull ? null : reader["PostalCode"]);
                    item.Country = Convert.ToString(reader["Country"] is DBNull ? null : reader["Country"]);
                    item.HomePhone = Convert.ToString(reader["HomePhone"] is DBNull ? null : reader["HomePhone"]);
                    item.Extension = Convert.ToString(reader["Extension"] is DBNull ? null : reader["Extension"]);
                    item.Photo = Convert.ToString(reader["Photo"] is DBNull ? null : reader["Photo"]);
                    item.Notes = Convert.ToString(reader["Notes"] is DBNull ? null : reader["Notes"]);
                    item.ReportsTo = Convert.ToInt32(reader["ReportsTo"] is DBNull ? null : reader["ReportsTo"]);
                    item.PhotoPath = Convert.ToString(reader["PhotoPath"] is DBNull ? null : reader["PhotoPath"]);

                    item.ReportsToEmployee = new Employees();
                    item.ReportsToEmployee.FirstName = Convert.ToString(reader["ReportsToFirstName"]);
                    item.ReportsToEmployee.LastName = Convert.ToString(reader["ReportsToLastName"]);



                    list.Add(item);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteEmployeeById(int id)
        {
            int result = 0;
            string queryString = "DELETE FROM Employees WHERE EmployeeID='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
     
        public int UpdateEmployee(Employees a)
        {
            int result = 0;
            string queryString = "UPDATE Employees SET LastName='" + a.LastName + "'," +
                " FirstName='" + a.FirstName + "'," +
                " Title='" + a.Title + "'," +
                " TitleOfCourtesy='" + a.TitleOfCourtesy + "'," +
                " BirthDate='" + a.BirthDate.ToString("yyyy-MM-dd") + "'," +
                " HireDate='" + a.HireDate.ToString("yyyy-MM-dd") + "'," +
                " Address='" + a.Address + "'," +
                " City='" + a.City + "'," +
                " Region='" + a.Region + "'," +
                " PostalCode='" + a.PostalCode + "'," +
                " Country='" + a.Country + "'," +
                " HomePhone='" + a.HomePhone + "'," +
                " Extension='" + a.Extension + "'," +
                " Photo='" + a.Photo + "'," +
                " Notes='" + a.Notes + "'," +
                " ReportsTo='" + a.ReportsTo + "'," +
                " PhotoPath='" + a.PhotoPath + "'" +
                " WHERE EmployeeID='" + a.EmployeeID + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public Employees GetEmployeeById(int id)
        {
            Employees item = null;
            string queryString = "SELECT * FROM Employees WHERE EmployeeID='" + id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new Employees();

                    item.EmployeeID = Convert.ToInt32(reader["EmployeeID"]);
                    item.LastName = Convert.ToString(reader["LastName"]);
                    item.FirstName = Convert.ToString(reader["FirstName"]);
                    item.Title = Convert.ToString(reader["Title"] is DBNull ? null : reader["Title"]);
                    item.TitleOfCourtesy = Convert.ToString(reader["TitleOfCourtesy"] is DBNull ? null : reader["TitleOfCourtesy"]);
                    item.BirthDate = Convert.ToDateTime(reader["BirthDate"] is DBNull ? null : reader["BirthDate"]);
                    item.HireDate = Convert.ToDateTime(reader["HireDate"] is DBNull ? null : reader["HireDate"]);
                    item.Address = Convert.ToString(reader["Address"] is DBNull ? null : reader["Address"]);
                    item.City = Convert.ToString(reader["City"] is DBNull ? null : reader["City"]);
                    item.Region = Convert.ToString(reader["Region"] is DBNull ? null : reader["Region"]);
                    item.PostalCode = Convert.ToString(reader["PostalCode"] is DBNull ? null : reader["PostalCode"]);
                    item.Country = Convert.ToString(reader["Country"] is DBNull ? null : reader["Country"]);
                    item.HomePhone = Convert.ToString(reader["HomePhone"] is DBNull ? null : reader["HomePhone"]);
                    item.Extension = Convert.ToString(reader["Extension"] is DBNull ? null : reader["Extension"]);
                    item.Photo = Convert.ToString(reader["Photo"] is DBNull ? null : reader["Photo"]);
                    item.Notes = Convert.ToString(reader["Notes"] is DBNull ? null : reader["Notes"]);
                    item.ReportsTo = Convert.ToInt32(reader["ReportsTo"] is DBNull ? null : reader["ReportsTo"]);
                    item.PhotoPath = Convert.ToString(reader["PhotoPath"] is DBNull ? null : reader["PhotoPath"]);
                }
                reader.Close();
            }
            return item;
        }

        public int InsertEmployee(Employees a)
        {
            int result = 0;
            string queryString = "INSERT INTO Employees(LastName,FirstName,Title,TitleOfCourtesy,BirthDate,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,Notes,ReportsTo,PhotoPath) " +
                "VALUES('" + a.LastName + "','"+a.FirstName + "','" + a.Title + "','" + a.TitleOfCourtesy + "','" + a.BirthDate.ToString("yyyy-MM-dd") + "','" + a.HireDate.ToString("yyyy-MM-dd") + "','" + a.Address + "','" + a.City + "','" + a.Region + "','" + a.PostalCode + "','" + a.Country + "','" + a.HomePhone + "','" + a.Extension + "','" + a.Photo + "','" + a.Notes + "','" + a.ReportsTo + "','" + a.PhotoPath + "'); " +
                "SELECT SCOPE_IDENTITY();";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = Convert.ToInt32(command.ExecuteScalar());
            }
            return result;
        }
    }
}