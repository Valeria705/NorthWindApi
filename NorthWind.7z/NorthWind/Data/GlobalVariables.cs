﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    internal class GlobalVariables
    {
        public static string conectionString = "Server=localhost;Database=NorthWind;User Id=sa;Password=12345;";

    }
}
