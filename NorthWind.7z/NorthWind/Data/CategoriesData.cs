﻿using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class CategoriesData
    {
        public List<Categories> GetAllCategories()
        {
            List<Categories> list = new List<Categories>();
            string queryString = "SELECT * FROM Categories";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {

                    Categories x = new Categories();

                    x.CategoryID = Convert.ToInt32( reader["CategoryID"]);
                    x.CategoryName = Convert.ToString( reader["CategoryName"]);
                    x.Description = Convert.ToString( reader["Description"]);
                    x.Picture = Convert.ToString(reader["Picture"]);



                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteCategorieById(int id)
        {
            int result = 0;
            string queryString = "DELETE FROM Categories WHERE CategoryID='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int UpdateCategorie(Categories a)
        {
            int result = 0;
            string queryString = "UPDATE Categories SET CategoryName='" + a.CategoryName + "', Description='" + a.Description + "', Picture='" + a.Picture + "' WHERE CategoryID='" + a.CategoryID + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public Categories GetCategorieById(int id)
        {
            Categories item = null;
            string queryString = "SELECT * FROM Categories WHERE CategoryID='" + id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new Categories();
                    item.CategoryID = Convert.ToInt32(reader["CategoryID"]);
                    item.CategoryName = Convert.ToString(reader["CategoryName"]);
                    item.Description = Convert.ToString(reader["Description"]);
                    item.Picture = Convert.ToString(reader["Picture"]);
                }
                reader.Close();
            }
            return item;
        }

        public int InsertCategorie(Categories a)
        {
            int result = 0;
            string queryString = "INSERT INTO Categories(CategoryName,Description,Picture) VALUES('" + a.CategoryName + "','"+a.Description + "','" + a.Picture + "')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
    }
}