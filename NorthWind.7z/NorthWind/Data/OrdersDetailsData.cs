﻿
using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class OrderDetailsData
    {
        public List<OrderDetails> GetOrderDetailsByOrderId(int idOrden)
        {
            List<OrderDetails> list = new List<OrderDetails>();
            string queryString = "SELECT * FROM OrderDetails WHERE OrderID='" + idOrden + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    OrderDetails x = new OrderDetails();
                    x.OrderID = Convert.ToInt32( reader["OrderID"]);
                    x.ProductID = Convert.ToInt32( reader["ProductID"]);
                    x.UnitPrice = Convert.ToDecimal( reader["UnitPrice"]);
                    x.Quantity = Convert.ToInt32(reader["Quantity"]);
                    x.Discount= Convert.ToSingle(reader["Discount"]);
                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteOrderDetailById(int id, int idProduct)
        {

            int result = 0;
            string queryString = "DELETE FROM OrderDetails WHERE OrderID='" + id + "'AND ProductID='" + idProduct + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int UpdateOrderDetail(OrderDetails a)
        {
            int result = 0;
            string queryString = "UPDATE OrderDetails SET UnitPrice ='" + a.UnitPrice + "', Quantity='" + a.Discount + "', Discount='" + a.Discount + "' WHERE OrderID='" + a.OrderID + "' AND ProductID='" + a.ProductID + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public OrderDetails GetOrderDetailById(int id)
        {
            OrderDetails item = null;
            string queryString = "SELECT * FROM OrderDetails WHERE OrderID='" + id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new OrderDetails();
                    item.OrderID = Convert.ToInt32(reader["OrderID"]);
                    item.ProductID = Convert.ToInt32(reader["ProductID"]);
                    item.UnitPrice = Convert.ToDecimal(reader["UnitPrice"]);
                    item.Quantity = Convert.ToInt32(reader["Quantity"]);
                    item.Discount = Convert.ToSingle(reader["Discount"]);
                }
                reader.Close();
            }
            return item;
        }

        public int InsertOrderDetail(OrderDetails a)
        {
            int result = 0;
            string queryString = "INSERT INTO OrderDetails(OrderID,ProductID,UnitPrice,Quantity,Discount) VALUES('" + a.OrderID + "','"+a.ProductID + "','" + a.UnitPrice + "','" + a.Quantity + "','" + a.Discount + "')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
    }
}