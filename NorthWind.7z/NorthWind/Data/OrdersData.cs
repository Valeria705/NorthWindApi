﻿
using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class OrdersData
    {
        public List<Orders> GetAllOrders()
        {
            List<Orders> list = new List<Orders>();
            string queryString = "SELECT Orders.*, Employees.FirstName, Customers.CompanyName FROM Orders INNER JOIN Employees ON Orders.EmployeeID = Employees.EmployeeID INNER JOIN Customers ON Orders.CustomerID = Customers.CustomerID";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Orders item = new Orders();
                    item.OrderID = Convert.ToInt32(reader["OrderID"]);
                    item.CustomerID = Convert.ToString(reader["CustomerID"] is DBNull ? null : reader["CustomerID"]);
                    item.EmployeeID = Convert.ToInt32(reader["EmployeeID"] is DBNull ? null : reader["EmployeeID"]);
                    item.OrderDate = Convert.ToDateTime(reader["OrderDate"] is DBNull ? null : reader["OrderDate"]);
                    item.RequiredDate = Convert.ToDateTime(reader["RequiredDate"] is DBNull ? null : reader["RequiredDate"]);
                    item.ShippedDate = Convert.ToDateTime(reader["ShippedDate"] is DBNull ? null : reader["ShippedDate"]);
                    item.ShipVia = Convert.ToInt32(reader["ShipVia"] is DBNull ? null : reader["ShipVia"]);
                    item.Freight = Convert.ToDecimal(reader["Freight"] is DBNull ? null : reader["Freight"]);
                    item.ShipName = Convert.ToString(reader["ShipName"] is DBNull ? null : reader["ShipName"]);
                    item.ShipAddress = Convert.ToString(reader["ShipAddress"] is DBNull ? null : reader["ShipAddress"]);
                    item.ShipCity = Convert.ToString(reader["ShipCity"] is DBNull ? null : reader["ShipCity"]);
                    item.ShipRegion = Convert.ToString(reader["ShipRegion"] is DBNull ? null : reader["ShipRegion"]);
                    item.ShipPostalCode = Convert.ToString(reader["ShipPostalCode"] is DBNull ? null : reader["ShipPostalCode"]);
                    item.ShipCountry = Convert.ToString(reader["ShipCountry"] is DBNull ? null : reader["ShipCountry"]);

                    item.Employees = new Employees();
                    item.Employees.EmployeeID = item.EmployeeID;
                    item.Employees.FirstName = Convert.ToString(reader["FirstName"]);

                    item.Customers = new Customers();
                    item.Customers.CustomerID = item.CustomerID;
                    item.Customers.CompanyName = Convert.ToString(reader["CompanyName"]);


                    list.Add(item);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteOrderById(int id)
        {
            int result = 0;
            string queryString = "DELETE FROM Orders WHERE OrderID='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
     
        public int UpdateOrder(Orders a)
        {
            int result = 0;
            string queryString = "UPDATE Orders SET CustomerID='" + a.CustomerID + "'," +
                " EmployeeID='" + a.EmployeeID + "'," +
                " OrderDate='" + a.OrderDate.ToString("yyyy-MM-dd") + "'," +
                " RequiredDate='" + a.RequiredDate.ToString("yyyy-MM-dd") + "'," +
                " ShippedDate='" + a.ShippedDate.ToString("yyyy-MM-dd") + "'," +
                " ShipVia='" + a.ShipVia + "'," +
                " Freight='" + a.Freight + "'," +
                " ShipName='" + a.ShipName + "'," +
                " ShipAddress='" + a.ShipAddress + "'," +
                " ShipCity='" + a.ShipCity + "'," +
                " ShipRegion='" + a.ShipRegion + "'," +
                " ShipPostalCode='" + a.ShipPostalCode + "'," +
                " ShipCountry='" + a.ShipCountry + "'" +
                " WHERE OrderID='" + a.OrderID + "'";

            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public Orders GetOrderById(int id)
        {
            Orders item = null;
            string queryString = "SELECT * FROM Orders WHERE OrderID='" + id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new Orders();

                    item.OrderID = Convert.ToInt32(reader["OrderID"]);
                    item.CustomerID = Convert.ToString(reader["CustomerID"]);
                    item.EmployeeID = Convert.ToInt32(reader["EmployeeID"]);
                    item.OrderDate = Convert.ToDateTime(reader["OrderDate"]);
                    item.RequiredDate = Convert.ToDateTime(reader["RequiredDate"]);
                    item.ShippedDate = Convert.ToDateTime(reader["ShippedDate"] is DBNull ? null : reader["ShippedDate"]);
                    item.ShipVia = Convert.ToInt32(reader["ShipVia"]);
                    item.Freight = Convert.ToDecimal(reader["Freight"]);
                    item.ShipName = Convert.ToString(reader["ShipName"]);
                    item.ShipAddress = Convert.ToString(reader["ShipAddress"]);
                    item.ShipCity = Convert.ToString(reader["ShipCity"]);
                    item.ShipRegion = Convert.ToString(reader["ShipRegion"]);
                    item.ShipPostalCode = Convert.ToString(reader["ShipPostalCode"]);
                    item.ShipCountry = Convert.ToString(reader["ShipCountry"]);
                }
                reader.Close();
            }
            return item;
        }

        public int InsertOrder(Orders a)

        {
            

            int result = 0;
            string queryString = "INSERT INTO Orders(CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) " +
                "VALUES('" + a.CustomerID + "','"+a.EmployeeID + "','" + a.OrderDate.ToString("yyyy-MM-dd") + "','" + a.RequiredDate.ToString("yyyy-MM-dd") + "','" + a.ShippedDate.ToString("yyyy-MM-dd") + "','" + a.ShipVia + "','" + a.Freight + "','" + a.ShipName + "','" + a.ShipAddress + "','" + a.ShipCity + "','" + a.ShipRegion + "','" + a.ShipPostalCode + "','" + a.ShipCountry + "')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
    }
}