﻿
using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class TerritoriesData
    {
        //Forma 1 - Resolver dependencias
        private RegionData regionData = new RegionData();

        public List<Territories> GetAllTerritories()
        {
            List<Territories> list = new List<Territories>();

            //Forma 1 - Resolver dependencias
            //string queryString = "SELECT * FROM Territories";

            //Forma 2 - Joins
            string queryString = "SELECT Territories.*,Region.RegionDescription " +
                "FROM Territories INNER JOIN Region ON Territories.RegionID = Region.RegionID";

            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Territories x = new Territories();
                    x.TerritoryID = Convert.ToString( reader["TerritoryID"]);
                    x.TerritoryDescription = Convert.ToString( reader["TerritoryDescription"]);
                    x.RegionID = Convert.ToInt32( reader["RegionID"]);
                    
                    //Forma 1 - Resolver dependencias
                    x.Region = regionData.GetRegionById(x.RegionID);

                    //Forma 2 
                    x.Region = new Region();
                    x.Region.RegionID = x.RegionID;
                    x.Region.RegionDescription = Convert.ToString(reader["RegionDescription"]);


                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteTerritorieById(string id)
        {
            int result = 0;
            string queryString = "DELETE FROM Territories WHERE TerritoryID='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int UpdateTerritorie(Territories a)
        {
            int result = 0;
            string queryString = "UPDATE Territories SET TerritoryDescription='" + a.TerritoryDescription + "', RegionID='" + a.RegionID + "' WHERE TerritoryID='"+a.TerritoryID+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public Territories GetTerritorieById(string id)
        {
            Territories item = null;
            string queryString = "SELECT * FROM Territories WHERE TerritoryID='"+id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new Territories();
                    item.TerritoryID = Convert.ToString(reader["TerritoryID"]);
                    item.TerritoryDescription = Convert.ToString(reader["TerritoryDescription"]);
                    item.RegionID= Convert.ToInt32(reader["RegionID"]);
                }
                reader.Close();
            }
            return item;
        }

        public int InsertTerritorie(Territories a)
        {
            int result = 0;
            string queryString = "INSERT INTO Territories(TerritoryID,TerritoryDescription,RegionID) VALUES('" + a.TerritoryID + "','" + a.TerritoryDescription+"','"+a.RegionID+"')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
    }
}