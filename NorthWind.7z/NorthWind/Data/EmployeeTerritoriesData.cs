﻿using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class EmployeeTerritoriesData
    {

        public List<EmployeeTerritories> GetEmployeeTerritoriesByEmployeeId(int employeeID)
        {
            List<EmployeeTerritories> list = new List<EmployeeTerritories>();
            string queryString = "SELECT * FROM EmployeeTerritories WHERE EmployeeID='" + employeeID + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    EmployeeTerritories x = new EmployeeTerritories();
                    x.EmployeeID = Convert.ToInt32( reader["EmployeeID"]);
                    x.TerritoryID = Convert.ToString( reader["TerritoryID"]);
                 
                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteEmployeeTerritorieByEmployeeID(int employeeID)
        {

            int result = 0;
            string queryString = "DELETE FROM EmployeeTerritories WHERE EmployeeID='" + employeeID + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int InsertEmployeeTerritorie(EmployeeTerritories a)
        {
            int result = 0;
          string queryString = "INSERT INTO EmployeeTerritories(EmployeeID,TerritoryID) VALUES('" + a.EmployeeID + "','" + a.TerritoryID + "')";
          using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
          {
              SqlCommand command = new SqlCommand(queryString, connection);
              connection.Open();
              result = command.ExecuteNonQuery();
          }
            return result;
        }
    }
}