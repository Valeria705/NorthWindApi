﻿
using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class CustomerDemographicsData
    {
        public List<CustomerDemographics> GetAllCustomerDemographics()
        {
            List<CustomerDemographics> list = new List<CustomerDemographics>();
            string queryString = "SELECT * FROM CustomerDemographics";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    CustomerDemographics x = new CustomerDemographics();
                    x.CustomerTypeID = Convert.ToString( reader["CustomerTypeID"]);
                    x.CustomerDesc = Convert.ToString( reader["CustomerDesc"]);
                  
                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteCustomerDemographicsById(string id)
        {
            int result = 0;
            string queryString = "DELETE FROM CustomerDemographics WHERE CustomerTypeID='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int UpdateCustomerDemographics(CustomerDemographics a)
        {
            int result = 0;
            string queryString = "UPDATE CustomerDemographics SET CustomerDesc='" + a.CustomerDesc + "' WHERE CustomerTypeID='" + a.CustomerTypeID+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public CustomerDemographics GetCustomerDemographicsById(string id)
        {
            CustomerDemographics item = null;
            string queryString = "SELECT * FROM CustomerDemographics WHERE CustomerTypeID='" + id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new CustomerDemographics();
                    item.CustomerTypeID = Convert.ToString(reader["CustomerTypeID"]);
                    item.CustomerDesc = Convert.ToString(reader["CustomerDesc"]);
       
                }
                reader.Close();
            }
            return item;
        }

        public int InsertCustomerDemographics(CustomerDemographics a)
        {
            int result = 0;
            string queryString = "INSERT INTO CustomerDemographics(CustomerTypeID, CustomerDesc) VALUES('" + a.CustomerTypeID + "','" + a.CustomerDesc + "')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
    }
}