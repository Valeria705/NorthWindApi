﻿
using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class UsersData
    {
        

        public List<Users> GetAllUsers()
        {
            List<Users> list = new List<Users>();

            //Forma 1 - Resolver dependencias
            //string queryString = "SELECT * FROM Users";

       
            string queryString = "SELECT * FROM Users ";
              

            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Users x = new Users();
                    x.IdUser = Convert.ToInt32( reader["IdUser"]);
                    x.FirtsNameUser = Convert.ToString( reader["FirtsNameUser"]);
                    x.LastsNameUser = Convert.ToString( reader["LastsNameUser"]);
                    x.Email = Convert.ToString(reader["Email"]);
                    x.Phone = Convert.ToString(reader["Phone"]);
                    x.Password = Convert.ToString(reader["Password"]);

                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteUserById(string id)
        {
            int result = 0;
            string queryString = "DELETE FROM Users WHERE IdUser='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int UpdateUser(Users a)
        {
            int result = 0;
            string queryString = "UPDATE Users SET FirtsNameUser='" + a.FirtsNameUser + "', LastsNameUser='" + a.LastsNameUser + "', Email='" + a.Email + "', Phone='" + a.Phone + "', Password='" + a.Password + "' WHERE IdUser='" + a.IdUser+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public Users GetUserById(string id)
        {
            Users item = null;
            string queryString = "SELECT * FROM Users WHERE IdUser= '"+id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new Users();
                    item.IdUser = Convert.ToInt32(reader["IdUser"]);
                    item.FirtsNameUser = Convert.ToString(reader["FirtsNameUser"]);
                    item.LastsNameUser = Convert.ToString(reader["LastsNameUser"]);
                    item.Email = Convert.ToString(reader["Email"]);
                    item.Phone = Convert.ToString(reader["Phone"]);
                    item.Password = Convert.ToString(reader["Password"]);
                }
                reader.Close();
            }
            return item;
        }
        public Users GetUserByLoginAndPassword(string email, string password )
        {
            Users item = null;
            string queryString = "SELECT * FROM Users WHERE Email='"+ email + "' AND Password='"+ password + "'";

            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new Users();
                    item.IdUser = Convert.ToInt32(reader["IdUser"]);
                    item.FirtsNameUser = Convert.ToString(reader["FirtsNameUser"]);
                    item.LastsNameUser = Convert.ToString(reader["LastsNameUser"]);
                    item.Email = Convert.ToString(reader["Email"]);
                    item.Phone = Convert.ToString(reader["Phone"]);
                    item.Password = Convert.ToString(reader["Password"]);
                }
                reader.Close();
            }
            return item;
        }

        public int InsertUser(Users a)
        {
            int result = 0;
            string queryString = "INSERT INTO Users(FirtsNameUser,LastsNameUser,Email,Phone,Password) VALUES('" + a.FirtsNameUser + "','" + a.LastsNameUser + "','"+a.Email + "','" + a.Phone + "','" + a.Password + "')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

    }
}