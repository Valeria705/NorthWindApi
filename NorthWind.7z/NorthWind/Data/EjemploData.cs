﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class EjemploData
    {
        int x = 0;

        void imprimirHola()
        {
            Console.WriteLine("hOLA");
        }

    }
}