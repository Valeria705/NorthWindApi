﻿
using Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NorthWind.Data
{
    public class ShippersData
    {
        public IEnumerable<Shippers> GetAllShippers()
        {
            List<Shippers> list = new List<Shippers>();
            string queryString = "SELECT * FROM Shippers";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Shippers x = new Shippers();
                    x.ShipperID = Convert.ToInt32( reader["ShipperID"]);
                    x.CompanyName = Convert.ToString( reader["CompanyName"]);
                    x.Phone = Convert.ToString( reader["Phone"]);
                    list.Add(x);
                }
                reader.Close();
            }
            return list;
        }

        public int DeleteShipperById(int id)
        {
            int result = 0;
            string queryString = "DELETE FROM Shippers WHERE ShipperID='" + id + "'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public int UpdateShipper(Shippers a)
        {
            int result = 0;
            string queryString = "UPDATE Shippers SET CompanyName='" + a.CompanyName + "', Phone='" + a.Phone + "' WHERE ShipperID='"+a.ShipperID+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }

        public Shippers GetShipperById(int id)
        {
            Shippers item = null;
            string queryString = "SELECT * FROM Shippers WHERE ShipperID='"+id+"'";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new Shippers();
                    item.ShipperID = Convert.ToInt32(reader["ShipperID"]);
                    item.CompanyName = Convert.ToString(reader["CompanyName"]);
                    item.Phone = Convert.ToString(reader["Phone"]);
                }
                reader.Close();
            }
            return item;
        }

        public int InsertShipper(Shippers a)
        {
            int result = 0;
            string queryString = "INSERT INTO Shippers(CompanyName,Phone) VALUES('"+a.CompanyName+"','"+a.Phone+"')";
            using (SqlConnection connection = new SqlConnection(GlobalVariables.conectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                connection.Open();
                result = command.ExecuteNonQuery();
            }
            return result;
        }
    }
}