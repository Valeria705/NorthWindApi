using NUnit.Framework;

namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {

            if (true)
            {
                Assert.Pass();
            }
            else
            {
                Assert.Fail();
            }
            
        }


        [Test]
        public void Test2()
        {

            if (true)
            {
                Assert.Pass();
            }
            else
            {
                Assert.Fail();
            }

        }
    }
}