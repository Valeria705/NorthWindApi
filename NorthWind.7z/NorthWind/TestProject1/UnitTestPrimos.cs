using NorthWind.Services;
using NUnit.Framework;

namespace TestProject1
{
    public class UnitTestPrimos
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestPrimo7()
        {
            Matematicas x = new Matematicas();
            if (!x.isPrimo(7))
            {
                Assert.Fail();  
            }
            Assert.Pass();
        }


        [Test]
        public void TestNoPrimo8()
        {
            Matematicas x = new Matematicas();
            if (x.isPrimo(8))
            {
                Assert.Fail();
            }
            Assert.Pass();
        }

        [Test]
        public void TestNegativo()
        {
            Matematicas x = new Matematicas();
            if (x.isPrimo(-8))
            {
                Assert.Fail();
            }
            Assert.Pass();
        }

    }
}