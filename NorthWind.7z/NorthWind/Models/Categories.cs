﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Models
{
    public class Categories
    {
        private int categoryID;
        private string picture;
        private string categoryName;
        private string description;

        public int CategoryID { get => categoryID; set => categoryID = value; }
        public string Picture { get => picture; set => picture = value; }
        public string CategoryName { get => categoryName; set => categoryName = value; }
        public string Description { get => description; set => description = value; }
    }
}