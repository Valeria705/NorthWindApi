﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Models
{
    public class EmployeeTerritories
    {
        private int employeeID;
        private string territoryID;

        public int EmployeeID { get => employeeID; set => employeeID = value; }
        public string TerritoryID { get => territoryID; set => territoryID = value; }
    }
}