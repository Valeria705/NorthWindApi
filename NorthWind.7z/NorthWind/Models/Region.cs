﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Models
{
    public class Region
    {
        private int regionID;
        private string regionDescription;

        public int RegionID { get => regionID; set => regionID = value; }
        public string RegionDescription { get => regionDescription; set => regionDescription = value; }
    }
}