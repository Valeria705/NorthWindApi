﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Models
{
    public class CustomerDemographics
    {
        private string customerTypeID;
        private string customerDesc;

        public string CustomerTypeID { get => customerTypeID; set => customerTypeID = value; }
        public string CustomerDesc { get => customerDesc; set => customerDesc = value; }
    }
}