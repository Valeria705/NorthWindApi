﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Models
{
    public class Shippers
    {
        private int shipperID;
        private string companyName;
        private string phone;

        public int ShipperID { get => shipperID; set => shipperID = value; }
        public string CompanyName { get => companyName; set => companyName = value; }
        public string Phone { get => phone; set => phone = value; }

    }
}