﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Models
{
    public class Territories
    {
        private string territoryID;
        private string territoryDescription;
        private int regionID;
        private Region region;

        public string TerritoryID { get => territoryID; set => territoryID = value; }
        public string TerritoryDescription { get => territoryDescription; set => territoryDescription = value; }
        public int RegionID { get => regionID; set => regionID = value; }
        public Region Region { get => region; set => region = value; }
    }
}