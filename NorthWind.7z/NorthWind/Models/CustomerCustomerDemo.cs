﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Models
{
    public class CustomerCustomerDemo
    {
        private string customerID;
        private string customerTypeID;

        public string CustomerID { get => customerID; set => customerID = value; }
        public string CustomerTypeID { get => customerTypeID; set => customerTypeID = value; }
    }
}