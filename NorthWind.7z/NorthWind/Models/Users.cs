﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Models
{
    public class Users

    {
        private int idUser;
        private string firtsNameUser;
        private string lastsNameUser;
        private string email;
        private string phone;
        private string password;

        public int IdUser { get => idUser; set => idUser = value; }
        public string FirtsNameUser { get => firtsNameUser; set => firtsNameUser = value; }
        public string LastsNameUser { get => lastsNameUser; set => lastsNameUser = value; }
        public string Email { get => email; set => email = value; }
        public string Phone { get => phone; set => phone = value; }
        public string Password { get => password; set => password = value; }
    }
}