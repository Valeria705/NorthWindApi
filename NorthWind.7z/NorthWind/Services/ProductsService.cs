﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class ProductsService
    {
        ProductsData productsData = new ProductsData();

        public List<Products> GetAllProducts() {
            return productsData.GetAllProducts();
        }

        public Products GetProductById(int id)
        {
            return productsData.GetProductById(id);
        }

        public int InsertProduct(Products a) 
        {
            return productsData.InsertProduct(a);
        }

        public int UpdateProduct(Products s)
        {
            return productsData.UpdateProduct(s);
        }

        public int DeleteProductById(int id)
        {
            return productsData.DeleteProductById(id);
        }
    }
}