﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class CustomerDemographicsService
    {
        CustomerDemographicsData CustomerDemographicsData = new CustomerDemographicsData();

        public List<CustomerDemographics> GetAllCustomerDemographics() {
            return CustomerDemographicsData.GetAllCustomerDemographics();
        }

        public CustomerDemographics GetCustomerDemographicsById(string id)
        {
            return CustomerDemographicsData.GetCustomerDemographicsById(id);
        }

        public int InsertCustomerDemographics(CustomerDemographics a) 
        {
            return CustomerDemographicsData.InsertCustomerDemographics(a);
        }

        public int UpdateCustomerDemographics(CustomerDemographics s)
        {
            return CustomerDemographicsData.UpdateCustomerDemographics(s);
        }

        public int DeleteCustomerDemographicsById(string id)
        {
            return CustomerDemographicsData.DeleteCustomerDemographicsById(id);
        }
    }
}