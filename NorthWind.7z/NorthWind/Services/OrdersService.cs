﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class OrdersService
    {
        OrdersData OrdersData = new OrdersData();

        public List<Orders> GetAllOrders() {
            return OrdersData.GetAllOrders();
        }

        public Orders GetOrderById(int id)
        {
            return OrdersData.GetOrderById(id);
        }

        public int InsertOrder(Orders a) 
        {
            return OrdersData.InsertOrder(a);
        }

        public int UpdateOrder(Orders s)
        {
            return OrdersData.UpdateOrder(s);
        }

        public int DeleteOrderById(int id)
        {
            return OrdersData.DeleteOrderById(id);
        }
    }
}