﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class ShippersService
    {
        ShippersData shippersData = new ShippersData();

        public IEnumerable<Shippers> GetAllShippers() {
            return shippersData.GetAllShippers();
        }

        public Shippers GetShipperById(int id)
        {
            return shippersData.GetShipperById(id);
        }

        public int InsertShipper(Shippers a) 
        {
            return shippersData.InsertShipper(a);
        }

        public int UpdateShipper(Shippers s)
        {
            return shippersData.UpdateShipper(s);
        }

        public int DeleteShipperById(int id)
        {
            return shippersData.DeleteShipperById(id);
        }
    }
}