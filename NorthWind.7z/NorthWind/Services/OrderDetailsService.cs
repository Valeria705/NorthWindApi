﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class OrderDetailsService
    {
        OrderDetailsData OrderDetailsData = new OrderDetailsData();

        public List<OrderDetails> GetOrderDetailsByOrderId(int id) {
            return OrderDetailsData.GetOrderDetailsByOrderId(id);
        }

        public OrderDetails GetOrderDetailById(int id)
        {
            return OrderDetailsData.GetOrderDetailById(id);
        }

        public int InsertOrderDetail(OrderDetails a) 
        {
            return OrderDetailsData.InsertOrderDetail(a);
        }

        public int UpdateOrderDetail(OrderDetails s)
        {
            return OrderDetailsData.UpdateOrderDetail(s);
        }

        public int DeleteOrderDetailById(int id, int idProduct)
        {
            return OrderDetailsData.DeleteOrderDetailById(id, idProduct);
        }
    }
}