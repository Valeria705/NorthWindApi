﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class UsersService
    {
        UsersData UsersData = new UsersData();

        public List<Users> GetAllUsers() {
            return UsersData.GetAllUsers();
        }

        public Users GetUserById(string id)
        {
            return UsersData.GetUserById(id);
        }

        public int InsertUser(Users a) 
        {
            return UsersData.InsertUser(a);
        }

        public int UpdateUser(Users s)
        {
            return UsersData.UpdateUser(s);
        }

        public int DeleteUserById(string id)
        {
            return UsersData.DeleteUserById(id);
        }

        public Users GetUserByLoginAndPassword(string email, string password) {
            return UsersData.GetUserByLoginAndPassword(email, password);
        }




    }
}