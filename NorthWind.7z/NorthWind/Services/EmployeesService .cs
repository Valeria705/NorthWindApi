﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class EmployeesService
    {
        EmployeesData employeesData = new EmployeesData();

        public List<Employees> GetAllEmployees() {
            return employeesData.GetAllEmployees();
        }

        public Employees GetEmployeeById(int id)
        {
            return employeesData.GetEmployeeById(id);
        }

        public int InsertEmployee(Employees a) 
        {
            return employeesData.InsertEmployee(a);
        }

        public int UpdateEmployee(Employees s)
        {
            return employeesData.UpdateEmployee(s);
        }

        public int DeleteEmployeeById(int id)
        {
            return employeesData.DeleteEmployeeById(id);
        }
    }
}