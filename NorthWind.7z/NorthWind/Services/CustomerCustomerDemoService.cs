﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class CustomerCustomerDemoService
    {
        CustomerCustomerDemoData customerCustomerDemoData = new CustomerCustomerDemoData();

        public List<CustomerCustomerDemo> GetCustomerCustomerDemoByCustomerId(string id) {
            return customerCustomerDemoData.GetCustomerCustomerDemoByCustomerId(id);
        }

        public int InsertCustomerCustomer(CustomerCustomerDemo a) 
        {
            return customerCustomerDemoData.InsertCustomer(a);
        }

        public int DeleteCustomerByCustomerID(string customerID)
        {
            return customerCustomerDemoData.DeleteCustomerByCustomerID(customerID);
        }
    }
}