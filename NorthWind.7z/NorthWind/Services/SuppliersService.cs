﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class SuppliersService
    {
        SuppliersData SuppliersData = new SuppliersData();

        public List<Suppliers> GetAllSuppliers() {
            return SuppliersData.GetAllSuppliers();
        }

        public Suppliers GetSupplierById(int id)
        {
            return SuppliersData.GetSupplierById(id);
        }

        public int InsertSupplier(Suppliers a) 
        {
            return SuppliersData.InsertSupplier(a);
        }

        public int UpdateSupplier(Suppliers s)
        {
            return SuppliersData.UpdateSupplier(s);
        }

        public int DeleteSupplierById(int id)
        {
            return SuppliersData.DeleteSupplierById(id);
        }
    }
}