﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class CategoriesService
    {
        private CategoriesData categoriesData = new CategoriesData();

        public List<Categories> GetAllCategories() {
            //aqui puede haber mucho codigo

            List<Categories> h = categoriesData.GetAllCategories();

            return h;
        }

        public Categories GetCategorieById(int id)
        {
            return categoriesData.GetCategorieById(id);
        }

        public int InsertCategorie(Categories a) 
        {
            return categoriesData.InsertCategorie(a);
        }

        public int UpdateCategorie(Categories s)
        {
            return categoriesData.UpdateCategorie(s);
        }

        public int DeleteCategorieById(int id)
        {
            return categoriesData.DeleteCategorieById(id);
        }
    }
}