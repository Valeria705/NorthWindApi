﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class RegionService
    {
        RegionData RegionData = new RegionData();

        public IEnumerable<Region> GetAllRegion() {
            return RegionData.GetAllRegion();
        }

        public Region GetRegionById(int id)
        {
            return RegionData.GetRegionById(id);
        }

        public int InsertRegion(Region a) 
        {
            return RegionData.InsertRegion(a);
        }

        public int UpdateRegion(Region s)
        {
            return RegionData.UpdateRegion(s);
        }

        public int DeleteRegionById(int id)
        {
            return RegionData.DeleteRegionById(id);
        }
    }
}