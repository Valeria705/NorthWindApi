﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class EmployeeTerritoriesService
    {
        EmployeeTerritoriesData EmployeeTerritoriesData = new EmployeeTerritoriesData();

        public List<EmployeeTerritories> GetEmployeeTerritoriesByEmployeeId(int id) {
            return EmployeeTerritoriesData.GetEmployeeTerritoriesByEmployeeId(id);
        }

        public int InsertEmployeeTerritorie(EmployeeTerritories a) 
        {
            return EmployeeTerritoriesData.InsertEmployeeTerritorie(a);
        }

        public int DeleteEmployeeTerritorieByEmployeeID(int employeeID)
        {
            return EmployeeTerritoriesData.DeleteEmployeeTerritorieByEmployeeID(employeeID);
        }
    }
}