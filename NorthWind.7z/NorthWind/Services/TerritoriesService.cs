﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class TerritoriesService
    {
        TerritoriesData TerritoriesData = new TerritoriesData();

        public List<Territories> GetAllTerritories() {
            return TerritoriesData.GetAllTerritories();
        }

        public Territories GetTerritorieById(string id)
        {
            return TerritoriesData.GetTerritorieById(id);
        }

        public int InsertTerritorie(Territories a) 
        {
            return TerritoriesData.InsertTerritorie(a);
        }

        public int UpdateTerritorie(Territories s)
        {
            return TerritoriesData.UpdateTerritorie(s);
        }

        public int DeleteTerritorieById(string id)
        {
            return TerritoriesData.DeleteTerritorieById(id);
        }

       
    }
}