﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class Matematicas
    {
        public bool isPrimo(int n)
        {

            if (n<1)
            {
                return false;
            }

            //variable auxiliar para guardar el resultado de la evaluacion
            bool esPrimo = true;

            //se divide el numero n entre todos los numeros anteriores
            for (int i = 2; i < n; i++)
            {
                //si el modulo de la division es 0 entonces el numero no es primo
                //se marca la variable esPrimo como false y se termina el for
                if (n % i == 0)
                {
                    esPrimo = false;
                    break;
                }
            }

            return esPrimo;
        }
    }
}