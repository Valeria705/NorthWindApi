﻿using NorthWind.Data;
using NorthWind.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthWind.Services
{
    public class CustomersService
    {
        CustomersData customersData = new CustomersData();

        public List<Customers> GetAllCustomers() {
            return customersData.GetAllCustomers();
        }

        public Customers GetCustomerById(string id)
        {
            return customersData.GetCustomerById(id);
        }

        public int InsertCustomer(Customers a) 
        {
            return customersData.InsertCustomer(a);
        }

        public int UpdateCustomer(Customers s)
        {
            return customersData.UpdateCustomer(s);
        }

        public int DeleteCustomerById(string id)
        {
            return customersData.DeleteCustomerById(id);
        }
    }
}